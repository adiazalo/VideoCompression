

mbSize = 40;
p = 8;
index = 0;
writer = VideoWriter('natalie_S_A_D.avi', ...
                        'Grayscale AVI');
writer.FrameRate = 30;
                    
open(writer);
       %%%%%% total frames = 281  
      
while index < 30
    
    index = index + 1;
    prev = frame_read('natalie_2.mp4', 720, 1280, index);
    curr = frame_read('natalie_2.mp4', 720, 1280, index + 1);
    [f_e, mx, my]= blockmatching(prev,curr,mbSize,p);
    
    k = mat2gray(f_e);
    %%% Uncomment to disply the predicated image 
%     figure
%     imshow(k);
    
    
 %%%%%%%%%%%% REading images/Frames from folder %%%%%%%%%%%%%%%%%%%%%%%   
%         index = index + 1;
%         filename  = sprintf('./frame/frame%d.jpg',index);
%         filename_1  = sprintf('./frame/frame%d.jpg',index + 1);
%         
%         prev_frame = imread(filename); 
%        curr_frame = imread(filename_1); 
       %%%%%%%%%%%%% SAD/MAD &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
% %           prev_frame = read_MP4Frame ('natalie_2.mp4', index);
% %           curr_frame = read_MP4Frame ('natalie_2.mp4', index + 1);
%        imgI = rgb2gray(prev_frame);
%        imgP = rgb2gray(curr_frame);
%        
%        [mx, my]=blockmatching(imgI,imgP,mbSize,p);
%        imgComp = motionComp(imgI, my, mx, mbSize);
%        %    figure
%        %
       %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%% Four steps search &&&&&&&&&&&&&&&&&&&&&&&&&&&&&

%      [motionVect, computations] = motionEst4SS(imgP,imgI,mbSize,p);
%     imgComp = motionComp(imgI, motionVect, mbSize);
   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%% Write images/frames to output file %%%%%%%%%%%%%%%%%%%%%%%%%%%
%     imwrite(k, 'natalie_1_reconst.jpg');    
%     img = imread('natalie_1_reconst.jpg');
%     writeVideo(writer,img); 
    
    writeVideo(writer,k); 
    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%5   
    prev = 0; curr =0;
    disp(index);
end

 close(writer);